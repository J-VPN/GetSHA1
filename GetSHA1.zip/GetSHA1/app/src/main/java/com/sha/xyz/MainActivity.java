package com.sha.xyz;

import android.app.*;
import android.os.*;
import vmodz.signaturechecker.status404error.*;

public class MainActivity extends Activity 
{
	private CheckSign cs;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		cs = new CheckSign(this);
		cs.setSHA1("54:69:ff:7f:a3:e0:36:f7:a6:2e:7d:58:06:b6:b3:a6:d3:9b:84:ef");
		cs.check();
    }
}
